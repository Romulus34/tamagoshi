module tamagohis.game {
}