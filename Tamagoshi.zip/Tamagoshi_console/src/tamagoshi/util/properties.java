package tamagoshi.util;

public class properties {

}
